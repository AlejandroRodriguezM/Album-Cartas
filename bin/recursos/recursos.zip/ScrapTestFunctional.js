const puppeteer = require('puppeteer');

async function extraerDatos(url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    await page.goto(url);

    // Aquí puedes escribir el código para extraer los datos que necesitas
    const datos = await page.evaluate(() => {
        // Ejemplo de extracción de título y texto de un elemento
        const titulo = document.title;
        const parrafos = Array.from(document.querySelectorAll('p')).map(p => p.textContent.trim());

        return {
            titulo,
            parrafos,
        };
    });

    await browser.close();

    return datos;
}

// Ejemplo de uso
const url = 'https://www.moxfield.com/decks/VgocEf5MwUC9SxeIj4iXzQ';
extraerDatos(url).then(datos => {
    console.log('Datos extraídos:', datos);
}).catch(error => {
    console.error('Error al extraer datos:', error);
});
