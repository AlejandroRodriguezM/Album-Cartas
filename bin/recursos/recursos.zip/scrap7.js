const puppeteer = require('puppeteer');

async function scrapeWeb(url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    try {
        await page.goto(url, { waitUntil: 'networkidle2' });

        let pageIndex = 0;
        let linksFound = true;
        const allLinks = [];

        while (linksFound) {
            const selector = `a[data-testid="product-card__image--${pageIndex}"]`;

            await page.waitForSelector(selector, { timeout: 5000 }).catch(() => {
                linksFound = false;
            });

            if (linksFound) {
                const links = await page.$$eval(selector, anchors =>
                    anchors.map(anchor => anchor.href)
                );

                allLinks.push(...links);
                pageIndex++;
            }
        }

        return allLinks;

    } catch (error) {
        throw new Error('Error scraping web: ' + error.message);
    } finally {
        await browser.close();
    }
}

async function getCardLinks(searchUrl) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    try {
        await page.goto(searchUrl, { timeout: 10000 });
        
        const finalUrl = page.url();
        let cardLinks = [];

        if (finalUrl !== searchUrl) {
            console.log(finalUrl); // Imprimir el URL final si hubo redirección
        } else {
            cardLinks = await page.$$eval('a.card-grid-item-card', links =>
                links.map(link => link.href)
            );

            if (cardLinks.length === 0) {
                const singleCardLink = await page.$eval('a.card-profile', el => el.href).catch(() => null);
                if (singleCardLink) {
                    console.log(singleCardLink); // Imprimir el enlace individual si no hay múltiples resultados
                }
            } else {
                cardLinks.forEach(link => console.log(link)); // Imprimir cada enlace de carta encontrado
            }
        }

        if (cardLinks.length === 0) {
            console.error(`No se encontraron enlaces de cartas para la URL: ${searchUrl}`);
        }

    } catch (error) {
        console.error('Error:', error);
        throw error;
    } finally {
        await browser.close();
    }
}

// Ejemplo de uso:
const url = process.argv[2];

// Modo getCardLinks
getCardLinks(url).then(cardLinks => {
    if (cardLinks.length > 0) {
        console.log(cardLinks);
    } else {
        console.error('No card links found.');
    }
}).catch(error => {
    console.error('Error:', error);
});
