const puppeteer = require('puppeteer');

    async function scrapeWeb(url) {

    // Iniciar el navegador
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    try {
        // Navegar a la URL
        await page.goto(url, { waitUntil: 'networkidle2' });

        let pageIndex = 0;
        let linksFound = true;
        const allLinks = [];

        while (linksFound) {
            const selector = `a[data-testid="product-card__image--${pageIndex}"]`;

            // Esperar a que se cargue el elemento actual
            await page.waitForSelector(selector, { timeout: 5000 }).catch(() => {
                linksFound = false; // Si no se encuentra el elemento, detener el bucle
            });

            if (linksFound) {
                // Extraer el atributo href del elemento actual
                const links = await page.$$eval(selector, anchors =>
                    anchors.map(anchor => anchor.href)
                );

                // Agregar los enlaces encontrados al array
                allLinks.push(...links);

                // Incrementar el índice para buscar el siguiente elemento
                pageIndex++;
            }
        }
        allLinks.forEach(link => console.log(link));

    } catch (error) {
        console.error('Error:', error);
    } finally {
        // Cerrar el navegador
        await browser.close();
    }
}

const url = process.argv[2];
scrapeWeb(url);
