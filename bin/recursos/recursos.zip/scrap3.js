const puppeteer = require('puppeteer');

async function scrapeWeb(url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    try {
        await page.goto(url, { waitUntil: 'networkidle2' });

        await page.waitForSelector('h1');
        await page.waitForSelector('img.v-lazy-image-loaded');
        await page.waitForSelector('span[data-testid="lblProductDetailsSetName"]');
        await page.waitForSelector('a[data-testid="lnkProductDetailsCategoryLine"]');

        let titulo = await page.$eval('h1', h1 => h1.textContent.trim());
        titulo = titulo.split(' -')[0]; // Extract the part before the first ' - '
        const direccionImagen = await page.$eval('img.v-lazy-image-loaded', img => img.getAttribute('src'));
        const coleccion = await page.$eval('span[data-testid="lblProductDetailsSetName"]', span => span.textContent.trim());
        const categoria = await page.$eval('a[data-testid="lnkProductDetailsCategoryLine"]', a => a.textContent.trim());

        let normas = null;

        // Verificar si existe el div.product__item-details__description
        const divExists = await page.$('div.product__item-details__description') !== null;

        if (divExists) {
            normas = await page.$eval('div.product__item-details__description', div => div.textContent.trim());
        } else {
            normas = await page.evaluate(() => {
                const allStrongElements = Array.from(document.querySelectorAll('strong[data-v-b277cce0]'));
                let cardTextContent = '';
                let attackContent = '';

                for (let strongElement of allStrongElements) {
                    const text = strongElement.textContent.trim();
                    const span = strongElement.nextElementSibling;

                    if (text === 'Card Text:') {
                        cardTextContent = span ? span.innerText.trim().replace(/\n/g, ' ') : '';
                    } else if (text.startsWith('Attack')) {
                        attackContent += (span ? ` ${span.innerText.trim().replace(/\n/g, ' ')}` : '');
                    }
                }

                // Devolver la combinación de 'Card Text:' y todos los 'Attack'
                return (cardTextContent + attackContent).trim() || null;
            });
        }

        let rareza = '';
        let numero = '';

        if (categoria === 'YuGiOh Cards') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Number'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        } else if (categoria === 'Magic: The Gathering Cards') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('#'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        } else if (categoria === 'One Piece Card Game') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Number:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        } else if (categoria === 'Pokemon Cards') {
            const cardNumberRarity = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Card Number / Rarity:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            [numero, rareza] = cardNumberRarity.split(' / ').map(item => item.trim());
        } else if (categoria === 'Disney Lorcana') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Number:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        } else if (categoria === 'Digimon TCG') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Number:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        } else if (categoria === 'Dragon Ball Super: Masters' || categoria === 'Dragon Ball Super: Fusion World') {
            rareza = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Rarity'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
            numero = await page.evaluate(() => {
                const strong = Array.from(document.querySelectorAll('strong')).find(el => el.textContent.includes('Number:'));
                return strong ? strong.nextElementSibling.textContent.trim() : '';
            });
        }

        let precioNormal = '0';
        let precioFoil = '0';

const priceDivs = await page.$$eval('div.charts-color', divs => {
    let prices = { normal: '0', foil: '0' };
    divs.forEach(div => {
        const title = div.querySelector('div.charts-title')?.textContent.trim();
        let price = div.querySelector('div.charts-price')?.textContent.trim();

        // Limpiar el precio para asegurar que solo contiene números y máximo un punto decimal
        price = price.match(/[0-9]+(?:\.[0-9]*)?/g)?.[0] || '0';

        if (title === 'Normal') {
            prices.normal = price;
        } else if (title === 'Foil') {
            prices.foil = price;
        }
    });
    return prices;
});

        precioNormal = priceDivs.normal;
        precioFoil = priceDivs.foil;

        console.log(`Titulo: ${titulo}`);
        console.log(`Numero: ${numero}`);
        console.log(`Categoria: ${categoria}`);
        console.log(`Coleccion: ${coleccion}`);
        console.log(`Rareza: ${rareza}`);
        console.log(`Precio Normal: ${precioNormal}`);
        console.log(`Precio Foil: ${precioFoil}`);
        console.log(`Referencia: ${url}`);
        console.log(`Dirección de la imagen: ${direccionImagen}`);
        console.log(`Normas: ${normas}`);
    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}
const url = process.argv[2];
scrapeWeb(url);
