const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// Variable para almacenar todos los enlaces filtrados
let todosEnlaces = [];

// Función principal para iniciar el proceso de extracción
async function extraerUrlsCardMarket(urlInicial) {
    let browser;
    try {
        browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
        const cardUrlsWithCounts = await extraerUrlsCartas(browser, urlInicial);
        for (let { url, count } of cardUrlsWithCounts) {
            for (let i = 0; i < count; i++) {
                await imprimirEnlaces(browser, url);
            }
        }

        // Después de terminar de extraer todos los enlaces, imprimir y guardar en archivo
        imprimirYGuardarEnlaces();
    } catch (error) {
        console.error('Error al extraer las URLs de cardMarket.com:', error);
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

// Función para extraer las URLs de las cartas de la página inicial junto con el número
async function extraerUrlsCartas(browser, url) {
    let page;
    try {
        page = await browser.newPage();
        await page.goto(url, { waitUntil: 'networkidle2' });
        await page.waitForSelector('div.XIi4jFys2lGhYwseGpBo');

        const cardUrlsWithCounts = await page.evaluate(() => {
            const cardLinks = [];
            const elements = document.querySelectorAll('div.XIi4jFys2lGhYwseGpBo a.table-deck-row-link');
            elements.forEach(element => {
                const parent = element.closest('div.XIi4jFys2lGhYwseGpBo');
                const countElement = parent.querySelector('div.dcD5V3uk1cjCKIMHR5hC.text-end');
                const count = countElement ? parseInt(countElement.textContent.trim(), 10) : 1;
                cardLinks.push({ url: element.href, count });
            });
            return cardLinks;
        });

        return cardUrlsWithCounts;
    } catch (error) {
        console.error('Error al extraer las URLs de cartas:', error);
        return [];
    } finally {
        if (page) {
            await page.close();
        }
    }
}

// Función para imprimir enlaces de cada URL de carta y guardarlos en la variable todosEnlaces
async function imprimirEnlaces(browser, url) {
    let page;
    try {
        page = await browser.newPage();
        await page.goto(url, { waitUntil: 'networkidle2' });
        await page.waitForSelector('a.btn');

        const enlaces = await page.evaluate(() => {
            const links = Array.from(document.querySelectorAll('a.btn'));
            return links.map(link => ({
                href: link.href,
                text: link.textContent.trim()
            }));
        });

        const enlacesFiltrados = enlaces.filter(enlace => enlace.text.includes('Scryfall'));

        if (enlacesFiltrados.length > 0) {
            const cleanEnlaces = enlacesFiltrados.map(enlace => enlace.href.replace(/\?utm_source=moxfield/g, ''));
            todosEnlaces = todosEnlaces.concat(cleanEnlaces); // Agregar los enlaces filtrados a la variable global
            console.log(`Se han encontrado y almacenado ${cleanEnlaces.length} enlaces filtrados para ${url}`);
        } else {
            console.log(`No se encontró ningún enlace que contenga "Scryfall" para ${url}.`);
        }
    } catch (error) {
        console.error('Hubo un problema al intentar obtener los enlaces:', error.message);
    } finally {
        if (page) {
            await page.close();
        }
    }
}

// Función para imprimir y guardar todos los enlaces en un archivo al finalizar
function imprimirYGuardarEnlaces() {
    if (todosEnlaces.length > 0) {
        const filePath = path.join(__dirname, `cartasMazo_${getTimeStamp()}.txt`);
        const content = todosEnlaces.join('\n');
        fs.writeFileSync(filePath, content);
        console.log(`Todos los enlaces filtrados se han guardado en ${filePath}`);
    } else {
        console.log('No se encontraron enlaces filtrados para guardar.');
    }
}

// Función para obtener la marca de tiempo actual
function getTimeStamp() {
    const now = new Date();
    return `${now.getHours()}${now.getMinutes()}${now.getSeconds()}`;
}

// URL inicial para extraer las URLs de cartas
const urlInicial = 'https://www.moxfield.com/decks/iuFbsanhEkytBIFV0GILtQ';
extraerUrlsCardMarket(urlInicial);
