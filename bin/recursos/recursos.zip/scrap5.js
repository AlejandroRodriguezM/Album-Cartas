const puppeteer = require('puppeteer');

// Función principal para iniciar el proceso de extracción
async function extraerUrlsCardMarket(urlInicial) {
    let browser;
    try {
        browser = await puppeteer.launch();
        const cardUrls = await extraerUrlsCartas(browser, urlInicial);
        for (let cardUrl of cardUrls) {
            await imprimirEnlaces(browser, cardUrl);
        }
    } catch (error) {
        console.error('Error al extraer las URLs de cardMarket.com:', error);
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

// Función para extraer las URLs de las cartas de la página inicial
async function extraerUrlsCartas(browser, url) {
    const page = await browser.newPage();
    await page.goto(url);
    await page.waitForSelector('div.XIi4jFys2lGhYwseGpBo');

    const cardUrls = await page.evaluate(() => {
        const cardLinks = [];
        const elements = document.querySelectorAll('div.XIi4jFys2lGhYwseGpBo a.table-deck-row-link');
        elements.forEach(element => {
            cardLinks.push(element.href);
        });
        return cardLinks;
    });

    await page.close();
    return cardUrls;
}


async function imprimirEnlaces(browser, url) {
    try {

        // Iniciar Puppeteer y abrir una nueva página
        const page = await browser.newPage();

        // Navegar a la URL especificada
        await page.goto(url);

        // Esperar a que los enlaces con la clase 'btn' estén presentes en la página
        await page.waitForSelector('a.btn');

        // Obtener todos los enlaces <a> que tienen la clase 'btn'
        const enlaces = await page.evaluate(() => {
            const links = Array.from(document.querySelectorAll('a.btn'));
            return links.map(link => ({
                href: link.href,
                text: link.textContent.trim()
            }));
        });

        // Filtrar los enlaces cuyo texto contenga "Scryfall"
        const enlacesFiltrados = enlaces.filter(enlace => enlace.text.includes('Scryfall'));

        // Imprimir los enlaces encontrados con clave/valor
        if (enlacesFiltrados.length > 0) {
            enlacesFiltrados.forEach(enlace => {
                console.log(`${enlace.href}`);
            });
        } else {
            console.log('No se encontró ningún enlace que contenga "Scryfall".');
        }

    } catch (error) {
        console.error('Hubo un problema al intentar obtener los enlaces:', error.message);
    } finally {
        if (browser) {
            // Cerrar el navegador solo si se abrió correctamente
            await browser.close();
        }
    }
}
const urlInicial = 'https://www.moxfield.com/decks/VgocEf5MwUC9SxeIj4iXzQ';

extraerUrlsCardMarket(urlInicial);
