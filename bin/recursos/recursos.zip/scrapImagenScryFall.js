const puppeteer = require('puppeteer');

async function extractCardDetails(cardLinks) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    try {
        await page.goto(cardLinks, { timeout: 10000 });

        // Wait for the image to load
        await page.waitForSelector('img.card', { timeout: 10000 });

        const imageUrl = await page.evaluate(() => {
            // Obtener la dirección de la imagen
            const imageUrlElement = document.querySelector('img.card');
            const imageUrl = imageUrlElement ? imageUrlElement.getAttribute('src') : '';

            // Obtener el índice del primer '?'
            const index = imageUrl.indexOf('?');

            // Devolver la parte del URL antes del '?'
            return imageUrl.slice(0, index);
        });

        await browser.close();

        return imageUrl; // Devolver solo la dirección de la imagen sin el parámetro de consulta

    } catch (error) {
        console.error(error.message);
        await browser.close();
        return null;
    }
}

async function printData(url) {
    console.log(url);
}

const url = process.argv[2];

extractCardDetails(url).then(data => {
    if (data) {
        printData(data);
    } else {
        console.error('No se pudieron obtener los datos.');
    }
});
