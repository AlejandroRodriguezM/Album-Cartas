const puppeteer = require('puppeteer');

async function scrapeWeb(url) {
    const browser = await puppeteer.launch({
        headless: true, // Ejecutar en modo headless para mejorar la velocidad de carga
        args: ['--no-sandbox', '--disable-setuid-sandbox'], // Configuración necesaria para Docker
    });
    const page = await browser.newPage();

    try {
        await page.goto(url, {
            waitUntil: 'networkidle2',
            timeout: 10000, // Aumentar el timeout si la página es lenta en cargar
        });

        // Esperar a que la imagen cargue
        await page.waitForSelector('img.v-lazy-image-loaded', { timeout: 10000 });

        // Obtener la dirección de la imagen
        const direccionImagen = await page.$eval('img.v-lazy-image-loaded', img => img.getAttribute('src'));

        console.log(direccionImagen);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await browser.close();
    }
}

const url = process.argv[2];
scrapeWeb(url);
