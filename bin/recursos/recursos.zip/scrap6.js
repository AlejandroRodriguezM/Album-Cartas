const puppeteer = require('puppeteer');

async function extractCardDetails(cardLinks) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    try {
        await page.goto(cardLinks, { timeout: 10000 });

        const details = await page.evaluate(() => {
            const details = {};

            details.name = document.querySelector('span.card-text-card-name').textContent.trim();

            // Número y Rareza
            const detailsElements = document.querySelector('span.prints-current-set-details');
            if (detailsElements) {
                const detailsText = detailsElements.textContent;

                // Extraer el número de la carta
                const numberRegex = /#(\d+)/;
                const numberMatch = detailsText.match(numberRegex);
                details.number = numberMatch ? numberMatch[1] : '';

                // Extraer la rareza de la carta
                const rarityRegex = /·\s*([a-zA-Z\s]+)/;
                const rarityMatch = detailsText.match(rarityRegex);
                details.rareza = rarityMatch ? rarityMatch[1].trim() : '';
            }

            // Colección
            details.collection = document.querySelector('span.prints-current-set-name').textContent.trim();

            // Imagen
            // const imageUrlElement = document.querySelector('img.card');
            // details.imageUrl = imageUrlElement ? imageUrlElement.getAttribute('src') : '';

            // Normas
            const normasElement = document.querySelector('div.card-text-box div.card-text-oracle p');
            details.normasCarta = normasElement ? normasElement.textContent.trim() : '';

            // Precios normales y foil en Cardmarket
            details.normalPrice = getPrice('span.currency-eur', 'Buy on Cardmarket');
            details.foilPrice = getPrice('span.currency-eur', 'Buy foil on Cardmarket');

            // Validar y ajustar precios si ninguno está disponible en Cardmarket
            if (!details.normalPrice && !details.foilPrice) {
                // Obtener precios en TCGplayer en caso de ausencia en Cardmarket
                details.normalPrice = getPrice('span.currency-usd', 'Buy on TCGplayer');
                details.foilPrice = getPrice('span.currency-usd', 'Buy foil on TCGplayer');
            }

            // Asegurarse de que los precios estén definidos si aún no lo están
            if (!details.normalPrice) {
                details.normalPrice = "0.0";
            }
            if (!details.foilPrice) {
                details.foilPrice = "0.0";
            }

            return details;

            function getPrice(selector, text) {
                let price = "";
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    const prevSibling = element.previousElementSibling;
                    if (prevSibling && prevSibling.tagName === 'I' && prevSibling.textContent.trim() === text) {
                        price = element.textContent.trim();
                    }
                });
                return price;
            }
        });

        await browser.close();

        return {
            name: details.name,
            number: details.number,
            editorial: "Magic: The Gathering",
            collection: details.collection,
            rareza: details.rareza,
            precioNormal: cleanPrice(details.normalPrice),
            precioFoil: cleanPrice(details.foilPrice),
            urlReferencia: cardLinks,
            direccionImagen: details.imageUrl,
            normas: details.normasCarta
        };

    } catch (error) {
        console.error(error.message);
        await browser.close();
        return null;
    }
}

function cleanPrice(price) {
    // Limpiar el precio y asegurar que sea un formato numérico adecuado (permitir también símbolos como $ y €)
    return price.replace(/[^\d.,€$]/g, ''); // Quitar caracteres no numéricos, excepto números, puntos, comas, € y $
}

function printData(data) {
    console.log('Referencia:', data.urlReferencia);
    console.log('Nombre:', data.name);
    console.log('Coleccion:', data.collection);
    console.log('Editorial:', data.editorial);
    console.log('Rareza:', data.rareza);
    console.log('Numero:', data.number);
    console.log('Valor:', data.precioNormal);
    console.log('Foil:', data.precioFoil);
    console.log('Normas:', data.normas);
    // console.log('Imagen:', data.direccionImagen);
}

const url = process.argv[2];

extractCardDetails(url).then(data => {
    if (data) {
        printData(data);
    } else {
        console.error('No se pudieron obtener los datos.');
    }
});
